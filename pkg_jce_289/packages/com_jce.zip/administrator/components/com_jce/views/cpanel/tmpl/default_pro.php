<div class="alert alert-info">
    <h4><i class="icon-star"></i> Go Pro and get more from JCE <a href="https://www.joomlacontenteditor.net/subscribe" class="btn btn-primary" target="_blank" title="Get JCE Editor Pro"><strong>Get JCE Editor Pro</strong></a></h4>
    <ul>
        <li>Resize, Thumbnail and Edit images</li>
        <li>Manage Audio and Video</li>
        <li>Create styled image captions</li>
        <li>Manage and create links to files</li>
        <li>Edit HTML in the Source Code Editor</li>
        <li>Write faster with <a href="https://en.wikipedia.org/wiki/Markdown" title="Markdown" target="_blank"><strong>Markdown</strong></a> support</li>
        <li>And much more...</li>
    </ul>
</div>